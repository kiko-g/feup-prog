FRANCISCO JOSE PAIVA GONCALVES  | 201704790
JOAO RUANO NETO VEIGA DE MACEDO | 201704464
PROJETO PROG | ENTREGA 2 | 19-05-2019 23h50
(Texto sem caracteres especiais/portugueses)

OBJETIVOS ("Funcionalidades a implementar")
1 - Completo
2 - Completo
3 - Completo
4 - Completo
5 - Completo
6 - Completo
7 - Completo
8 - Quase (mudanças de 10 minutos)
9 - Por fazer
10 - Por fazer

===================================================================================================
Desenlvovemos o projeto no VS CODE usando g++ e o powershell do windows
O comando 'g++ *.cpp /classes *.cpp' compila todos os programas na pasta

IMPORTANTE NOTAR que os ficheiros de texto estao dentro da pasta 'src/data' e o
programa esta implementado de maneira a considerar isso, existindo portanto uma 
funcao que faz 'reset' ao caminho para essas files sendo dps adicionado a esse 
caminho o nome da file.

O projeto ainda esta ligeiramente incompleto. Os objetivos base estao bem cumpridos e feitos com 
bastante cuidado, verificacao de modo a que seja uma navegacao agradavel e um trabalho
bem conseguido.

Agradecemos que compreendam a situacao e que nos seja permitido entregar ainda com 2 dias de atraso.
Vamos submeter o trabalho atraves da minha conta do moodle (Francisco Goncalves) por volta das 23h59 de 19/05 (domingo)
e depois mais tarde tentaremos desenvolver e submeter o mais depressa possivel o que falta nos pontos 9 e 10.
Se nao forem aceites, compreendemos e fica o trabalho submetido em primeiro lugar para efeito de avaliacao

As funcionalidades de pesquisa permitem pesquisar um cliente por nome (substring de nome e CASE SENSITIVE)
e tambem por NIF apesar de com o tempo apertado acabamos por apenas implementar a procura pelo NIF para efeito
de visualizacao de um so cliente (NIF/VAT ---> identificador)

(...)
===================================================================================================
