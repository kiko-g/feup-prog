#pragma once
#include <string>


const std::string AGENCY_FILE_NAME="agency.txt";
const std::string PATH_TO_DATA="data/";
const std::string LIMIT_STRING="::::::::::";

